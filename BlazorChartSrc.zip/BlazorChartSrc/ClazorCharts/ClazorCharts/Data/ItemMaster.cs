﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClazorCharts.Data
{
    public class ItemMaster
    {
        public String ItemName { get; set; }
        public int SaleCount { get; set; }
    }
}
